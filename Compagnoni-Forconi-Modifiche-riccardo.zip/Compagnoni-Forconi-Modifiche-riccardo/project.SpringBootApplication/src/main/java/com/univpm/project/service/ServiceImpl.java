package com.univpm.project.service;

public class ServiceImpl implements Service{
	public abstract void 
	
}
