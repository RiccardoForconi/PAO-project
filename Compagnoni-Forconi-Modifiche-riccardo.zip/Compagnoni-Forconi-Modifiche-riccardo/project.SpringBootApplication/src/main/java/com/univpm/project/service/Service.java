package com.univpm.project.service;

public interface Service {

}
